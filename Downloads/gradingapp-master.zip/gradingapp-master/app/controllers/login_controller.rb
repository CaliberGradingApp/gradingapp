class LoginController < ApplicationController
  def index
  end
end
